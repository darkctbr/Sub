package com.example.quizsub;

import java.util.List;

public class Resultado {
    private String texto;
    private List<String> opcoes;

    public Pergunta(String texto, List<String> opcoes) {
        this.texto = texto;
        this.opcoes = opcoes;
    }

    public String getTexto() {
        return texto;
    }

    public List<String> getOpcoes() {
        return opcoes;
    }
   

}
