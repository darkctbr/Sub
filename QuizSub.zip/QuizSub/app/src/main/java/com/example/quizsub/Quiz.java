package com.example.quizsub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Quiz extends AppCompatActivity {

    RadioGroup radioGroup1, radioGroup2, radioGroup3, radioGroup4, radioGroup5;
    Button buttonNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup1 = findViewById(R.id.radioGroup1);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        radioGroup4 = findViewById(R.id.radioGroup4);
        radioGroup5 = findViewById(R.id.radioGroup5);
        buttonNext = findViewById(R.id.buttonNext);

        buttonNext.setOnClickListener(v -> {
            List<String> respostasSelecionadas = new ArrayList<>();

            respostasSelecionadas.add(obterRespostaSelecionada(radioGroup1));
            respostasSelecionadas.add(obterRespostaSelecionada(radioGroup2));
            respostasSelecionadas.add(obterRespostaSelecionada(radioGroup3));
            respostasSelecionadas.add(obterRespostaSelecionada(radioGroup4));
            respostasSelecionadas.add(obterRespostaSelecionada(radioGroup5));

            if (respostasSelecionadas.contains("")) {
                Toast.makeText(this, "Responda todas as perguntas!", Toast.LENGTH_SHORT).show();
                return;
            }

            String perfil = calcularPerfil(respostasSelecionadas);
            Intent intent = new Intent(this, Resultado.class);
            intent.putExtra("perfil", perfil);
            startActivity(intent);
        });
    }

    private String obterRespostaSelecionada(RadioGroup group) {
        int selectedId = group.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selected = findViewById(selectedId);
            return selected.getText().toString();
        }
        return "";
    }
    private String calcularPerfil(List<String> respostas) {
        int pontosExplorador = 0;
        int pontosPreguicoso = 0;
        int pontosCuidadoso = 0;

        for (String r : respostas) {
            String resposta = r.trim().toLowerCase();

            if (
                    resposta.contains("natureza") ||
                            resposta.contains("aventura") ||
                            resposta.contains("conhecer") ||
                            resposta.contains("curioso") ||
                            resposta.contains("ideias")
            ) {
                pontosExplorador++;
            } else if (
                    resposta.contains("dormir") ||
                            resposta.contains("evito") ||
                            resposta.contains("série") ||
                            resposta.contains("relaxado") ||
                            resposta.contains("acompanhar")
            ) {
                pontosPreguicoso++;
            } else if (
                    resposta.contains("organizar") ||
                            resposta.contains("controle") ||
                            resposta.contains("planejar") ||
                            resposta.contains("responsável") ||
                            resposta.contains("detalhes")
            ) {
                pontosCuidadoso++;
            }
        }

        if (pontosExplorador >= pontosPreguicoso && pontosExplorador >= pontosCuidadoso) {
            return "Explorador";
        } else if (pontosPreguicoso >= pontosExplorador && pontosPreguicoso >= pontosCuidadoso) {
            return "Preguiçoso";
        } else {
            return "Cuidadoso";
        }
    }

}
