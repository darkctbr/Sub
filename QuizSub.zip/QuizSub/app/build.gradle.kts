// build.gradle.kts do módulo app
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
